import com.mongodb.*;
//
//import org.bson.BSONObject;
//import org.codehaus.jackson.JsonGenerationException;
//import org.codehaus.jackson.JsonParseException;
//import org.codehaus.jackson.map.JsonMappingException;
//import org.codehaus.jackson.map.ObjectMapper;
//
//import java.io.File;
//import java.io.IOException;
import java.net.UnknownHostException;
//import java.io.FileWriter;
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.util.*;

import org.json.JSONException;
import org.json.JSONObject;

public class ConnectToMongo {
	private DBCollection collection;
	private DB db;
	private MongoClient mongoClient;
	private JSONObject confJson;

	public ConnectToMongo(JSONObject confJson) {
		this.confJson = confJson;
		try {
			mongoClient = new MongoClient(new MongoClientURI(confJson.getString("mongoClientUri")));
			// gets the DB name from the configuration file
			this.db = mongoClient.getDB(confJson.getString("dbMongoName"));
//			boolean auth = db.authenticate(confJson.getString("mongoUserName"),
//					confJson.getString("mongoUserPassword").toCharArray());
//			if (auth) {
				// gets the collection name from the configuration file
				this.collection = db.getCollection(confJson.getString("collectionMongoName"));
//				System.out.println("Login is successful!");
//			} else {
//				System.out.println("Login is failed!");
//			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public DBCollection getCollection() {
		return collection;
	}

	public DB getDb() {
		return db;
	}

	public MongoClient getMongoClient() {
		return mongoClient;
	}
}
