import java.sql.*;

public class SybaseConnectionHandler {
	ResultSet r;
	Statement s;
	String returnStatus;
}
