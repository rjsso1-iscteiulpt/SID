 import com.mongodb.*;
//
//import org.bson.BSONObject;
//import org.codehaus.jackson.JsonGenerationException;
//import org.codehaus.jackson.JsonParseException;
//import org.codehaus.jackson.map.JsonMappingException;
//import org.codehaus.jackson.map.ObjectMapper;
//
//import java.io.File;
//import java.io.IOException;
import java.net.UnknownHostException;
//import java.io.FileWriter;
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.util.*;

public class ConnectToMongo {
	private DBCollection collection;
	private DB db;
	private MongoClient mongoClient;

	public ConnectToMongo() {
		try {
			mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		db = mongoClient.getDB("sensorMedicoes");
		collection = db.getCollection("Sensor");
	}

	public DBCollection getCollection() {
		return collection;
	}

	public DB getDb() {
		return db;
	}

	public MongoClient getMongoClient() {
		return mongoClient;
	}
}
