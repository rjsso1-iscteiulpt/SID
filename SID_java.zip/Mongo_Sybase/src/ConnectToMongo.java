import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import com.mongodb.*;

import org.bson.BSONObject;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class ConnectToMongo {
	private DBCollection collection;
	private DB db;
	private MongoClient mongoClient;

	public ConnectToMongo() {
		try {
			mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		db = mongoClient.getDB("sensorMedicoes");
		collection = db.getCollection("Sensor");
	}

	public DBCollection getCollection() {
		return collection;
	}

	public DB getDb() {
		return db;
	}

	public MongoClient getMongoClient() {
		return mongoClient;
	}

	public void insertMongo() {
		
	}
	
//	@Override
//	public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
//		if(mqttMessage.toString().equals("teste1")) {
//			System.out.println(mqttMessage);
//		}
//		//falta ter uma mensagem do sensor e converter para DBObject
//		BasicDBObject document = new BasicDBObject();
//		document.put("temperature", "29.1");
//		collection.insert(document);		
//	}
	



}
