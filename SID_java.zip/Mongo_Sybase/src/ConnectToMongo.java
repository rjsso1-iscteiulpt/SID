 import com.mongodb.*;
//
//import org.bson.BSONObject;
//import org.codehaus.jackson.JsonGenerationException;
//import org.codehaus.jackson.JsonParseException;
//import org.codehaus.jackson.map.JsonMappingException;
//import org.codehaus.jackson.map.ObjectMapper;
//
//import java.io.File;
//import java.io.IOException;
import java.net.UnknownHostException;
//import java.io.FileWriter;
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.util.*;

import org.json.JSONException;
import org.json.JSONObject;

public class ConnectToMongo {
	private DBCollection collection;
	private DB db;
	private MongoClient mongoClient;
	private JSONObject confJson;

	public ConnectToMongo(JSONObject confJson) {
		this.confJson=confJson;
		try {
			mongoClient = new MongoClient(new MongoClientURI(confJson.getString("mongoClientUri")));
			
			this.db = mongoClient.getDB(confJson.getString("dbMongoName"));
			this.collection = db.getCollection(confJson.getString("collectionMongoName"));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public DBCollection getCollection() {
		return collection;
	}

	public DB getDb() {
		return db;
	}

	public MongoClient getMongoClient() {
		return mongoClient;
	}
}
