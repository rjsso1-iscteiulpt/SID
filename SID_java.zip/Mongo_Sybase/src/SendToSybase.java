import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class SendToSybase implements Runnable{

	private ConnectionHandler connHandler;
	private ConnectToSybase connSybase;

	public SendToSybase(ConnectionHandler connHandler, ConnectToSybase connSybase) {
		this.connHandler = connHandler;
		this.connSybase = connSybase;
	}
	@Override
	public void run() {
		while (true) {
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			List<DBObject> dataFromMongo = connHandler.get();
				
			if(!dataFromMongo.isEmpty()) {
			for (DBObject result : dataFromMongo) {
				System.out.println(result);
				insert();
			}
			}
		}
	}

		public void insert() {

		try {
			Statement stmt = connSybase.getConn().createStatement();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date parsed = null;
			try {
				parsed = format.parse("2000-11-22");
			} catch (ParseException e) {
				e.printStackTrace();
			}
	        java.sql.Date sql = new java.sql.Date(parsed.getTime());
	        ResultSet resultset = stmt.executeQuery("SELECT MAX(IDMedicao) from HumidadeTemperatura");
	        System.out.println(resultset.toString());
			stmt.executeUpdate("INSERT INTO HumidadeTemperatura VALUES (6,'12:11:11:000','"+ sql+ "',2.1, 1.1)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
