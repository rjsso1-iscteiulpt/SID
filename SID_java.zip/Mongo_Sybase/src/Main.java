import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {

	public static void main(String[] args) {
		
		ConfFileReader reader = new ConfFileReader();
		reader.readFromFile();

		// estabelecimento das liga��es
//		ConnectToMongo connMongo = new ConnectToMongo();
//		ConnectToSybase connSybase = new ConnectToSybase("lab", "dba", "sql");

		// lidar com leituras e escritas
//		ConnectionHandler connHandler = new ConnectionHandler(connMongo, connSybase);

		// chama os m�todos de leitura e escrita
//		new ConnectToSensor(connHandler);
//		new Thread(new SendToSybase(connHandler, connSybase)).start();;
	}

}
