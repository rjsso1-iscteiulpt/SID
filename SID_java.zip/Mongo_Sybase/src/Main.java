
public class Main {

	public static void main(String[] args) {
		
		ConnectToMongo connMongo = new ConnectToMongo();
		ConnectToSensor connSensor = new ConnectToSensor(connMongo);
		ConnectToSybase connSybase = new ConnectToSybase("lab", "dba", "sql", connMongo);
		ConnectionHandler connHandler = new ConnectionHandler();
		
		
		while(true) {
//			connSybase.write(connMongo.read());
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

}
