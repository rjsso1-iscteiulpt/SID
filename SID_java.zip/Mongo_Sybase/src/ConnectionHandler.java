import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.sybase.jdbc4.jdbc.SybSavepoint;

public class ConnectionHandler {
	private ConnectToMongo connMongo;
	final Lock lock = new ReentrantLock();

	public ConnectionHandler(ConnectToMongo connMongo, ConnectToSybase connSybase) {
		this.connMongo = connMongo;
	}

	public synchronized List<DBObject> get() {
		lock.lock();
		try {
			DBCollection collection = connMongo.getCollection();
			BasicDBObject migratedQuery = new BasicDBObject();
			migratedQuery.put("migrated", new BasicDBObject("$eq", "false"));
			DBCursor results = collection.find(new BasicDBObject("migrated", "false"));
			
//			System.out.println(cursor);
//			while (cursor.hasNext()) {
//				System.out.println(cursor.next());
//			}
			return results.toArray();
		} finally {
			lock.unlock();
		}	
	}

	public synchronized void put(String value) {
		lock.lock();
		
		try {
			System.out.println("mongo");
//			 BasicDBObject document = new BasicDBObject();
//			 document.put("temperature", "39.1");
//			 connMongo.getCollection().insert(document);
		} finally {
			lock.unlock();
		}
	}

}
