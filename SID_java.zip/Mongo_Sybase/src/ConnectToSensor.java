import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class ConnectToSensor implements MqttCallback{

	private MqttClient mqttclient;
	private MqttConnectOptions connOpt;
	private ConnectionHandler connHandler;
	
	public ConnectToSensor(ConnectionHandler connHandler) {
		try {
			this.connHandler = connHandler;
			mqttclient = new MqttClient("tcp://iot.eclipse.org:1883", "sid_lab_2009");
			connOpt = new MqttConnectOptions();
			connOpt.setCleanSession(true);
			mqttclient.connect(connOpt);
			mqttclient.setCallback(this);
			mqttclient.subscribe("sid_lab_2009");
		} catch (MqttException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {
	}
	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		connHandler.put(message.toString());
	}

	@Override
	public void connectionLost(Throwable arg0) {
		System.out.println("Connection Lost");
	}
}
