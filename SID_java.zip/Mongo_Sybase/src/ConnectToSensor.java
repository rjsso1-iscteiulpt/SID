import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;

public class ConnectToSensor implements MqttCallback {

	private MqttClient mqttclient;
	private MqttConnectOptions connOpt;
	private ConnectToMongo connMongo;
	public ConnectToSensor(ConnectToMongo connMongo) {
		try {
			this.connMongo = connMongo;
			mqttclient = new MqttClient("tcp://iot.eclipse.org:1883", "sid_lab_2019");
			connOpt = new MqttConnectOptions();
			connOpt.setCleanSession(true);
			mqttclient.connect(connOpt);
			mqttclient.setCallback(this);
			mqttclient.subscribe("sid_lab_2019");
		} catch (MqttException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {
	}
	@Override
	public void messageArrived(String arg0, MqttMessage arg1) throws Exception {
		BasicDBObject document = new BasicDBObject();
		document.put("temperature", "39.1");
		connMongo.getCollection().insert(document);
	}

	@Override
	public void connectionLost(Throwable arg0) {
		// TODO Auto-generated method stub
		
	}
	
}
