import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class ConnectToSybase {
	static Connection conn;
	private ConnectToMongo connMongo;
	
	public ConnectToSybase(String db, String user, String passwd, ConnectToMongo connMongo) {
		try {
			this.connMongo = connMongo;
			conn = DriverManager.getConnection("jdbc:sqlanywhere:Tds:localhost:2638?eng=lab", "dba", "sql");
			conn.setAutoCommit(true);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Server down, unable to make the	connection. ");
		}
//		getDataFromMongo();
	}
	
	public void getDataFromMongo() {
		DBCollection collection = connMongo.getCollection();
		BasicDBObject gtQuery = new BasicDBObject();
		gtQuery.put("temperature", new BasicDBObject("$gt", 29.1));
		DBCursor cursor = collection.find(gtQuery);
		System.out.println(cursor);
		while(cursor.hasNext()) {
			System.out.println(cursor.next());
		}
	}
	//buscar do mongo
	//ver data
	//inserir sybase

	public void insert() {

		try {
			Statement stmt = conn.createStatement();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	        Date parsed = null;
			try {
				parsed = format.parse("2000-11-22");
			} catch (ParseException e) {
				e.printStackTrace();
			}
	        java.sql.Date sql = new java.sql.Date(parsed.getTime());
	        ResultSet resultset = stmt.executeQuery("SELECT MAX(IDMedicao) from HumidadeTemperatura");
	        System.out.println(resultset.toString());
//			stmt.executeUpdate("INSERT INTO HumidadeTemperatura VALUES (7,'"+ sql+ "',null,2.1, 1,1)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// Disable autocommit
		// conn.setAutoCommit( false );
		//
		// Statement stmt = conn.createStatement();
		//
		// Integer IRows = new Integer( stmt.executeUpdate
		// ("INSERT INTO Department (dept_id, dept_name )"
		// + "VALUES (201, 'Eastern Sales')"
		// ) );
		// // Print the number of rows updated
		// System.out.println(IRows.toString() + "row inserted" );
	}

	// ch.s.executeUpdate("Commit");
	
	

}
