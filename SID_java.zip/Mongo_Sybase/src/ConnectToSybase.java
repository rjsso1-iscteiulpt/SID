import java.sql.*;

public class ConnectToSybase {
	static Connection conn;
	
	public ConnectToSybase(String db, String user, String passwd) {
		try {
			conn = DriverManager.getConnection("jdbc:sqlanywhere:Tds:localhost:2638?eng="+db, user, passwd);
			conn.setAutoCommit(true);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Server down, unable to make the	connection. ");
		}
	}

	public static Connection getConn() {
		return conn;
	}
}
