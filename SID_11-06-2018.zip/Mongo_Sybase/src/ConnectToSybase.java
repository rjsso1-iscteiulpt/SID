import java.sql.*;

import org.json.JSONObject;

public class ConnectToSybase {
	static Connection conn;

	public ConnectToSybase(JSONObject confJson) {
		try {
			// Conecta-se ao Sybase, atrav�s do path da BD, do nome da BD, do username e password
			conn = DriverManager.getConnection(confJson.getString("dbSybasePath") + confJson.getString("dbSybaseName"),
					confJson.getString("sybaseUserName"), confJson.getString("sybaseUserPassword"));
			conn.setAutoCommit(true);
		} catch (Exception e) {
			System.out.println("Server down, unable to make the	connection. ");
		}
	}

	public static Connection getConn() {
		return conn;
	}
}
