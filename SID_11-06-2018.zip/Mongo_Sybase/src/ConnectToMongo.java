import com.mongodb.*;
import java.net.UnknownHostException;
import org.json.JSONException;
import org.json.JSONObject;

public class ConnectToMongo {
	private DBCollection collection;
	private DB db;
	private MongoClient mongoClient;

	public ConnectToMongo(JSONObject confJson) {
		try {
			// Gets username, password and the database name from the configuration file
			String username = confJson.getString("mongoUserName");
			String password = confJson.getString("mongoUserPassword");
			String dbName = confJson.getString("dbMongoName");

			// Connects to mongo with the username, password and database name
			mongoClient = new MongoClient(
					new MongoClientURI("mongodb://" + username + ":" + password + "@localhost:27017/" + dbName));

			// Gets the database and the collection
			// The database and collection names come from the configuration file
			this.db = mongoClient.getDB(dbName);
			this.collection = db.getCollection(confJson.getString("collectionMongoName"));
		} catch (JSONException e) {
			System.out.println("Error converting to JSON");
		} catch (UnknownHostException e) {
			System.out.println("Could not find host");
		}
	}

	public DBCollection getCollection() {
		return collection;
	}

	public DB getDb() {
		return db;
	}

	public MongoClient getMongoClient() {
		return mongoClient;
	}
}
