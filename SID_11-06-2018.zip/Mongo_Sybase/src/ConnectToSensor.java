import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

public class ConnectToSensor implements MqttCallback{

	private MqttClient mqttclient;
	private MqttConnectOptions connOpt;
	private ConnectionHandler connHandler;
	
	public ConnectToSensor(ConnectionHandler connHandler, JSONObject confJson) {
		try {
			this.connHandler = connHandler;
			mqttclient = new MqttClient(confJson.getString("mqqtClientLink"), confJson.getString("pahoTopic"));
			connOpt = new MqttConnectOptions();
			connOpt.setCleanSession(true);
			mqttclient.connect(connOpt);
			mqttclient.setCallback(this);
			mqttclient.subscribe(confJson.getString("pahoTopic"),0);
			System.out.println("Conectou");
		} catch (MqttException e) {
			System.out.println("MqttException");
		} catch (JSONException e) {
			System.out.println("JSONException");
		}
	}
	
	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {
	}
	@Override
	public void messageArrived(String topic, MqttMessage message) {
		try {
			System.out.println("recebeu");
			connHandler.put(message.toString());
		}catch(Exception e){
			System.out.println("Tipo de mensagem errado");
		}
	}

	@Override
	public void connectionLost(Throwable me) {
		System.out.println(me);
	}
}
