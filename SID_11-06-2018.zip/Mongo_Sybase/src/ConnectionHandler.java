import java.awt.BorderLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class ConnectionHandler {
	private static final double TEMPERATURELOW = -273;
	private static final double TEMPERATUREHIGH = 150;
	private static final double HUMIDITYLOW = 0;
	private static final double HUMIDITYHIGH = 100;
	private static final int DATELOW = 1970;
	private ConnectToMongo connMongo;
	private boolean available = false;

	public ConnectionHandler(ConnectToMongo connMongo, ConnectToSybase connSybase) {
		this.connMongo = connMongo;
	}

	public synchronized List<DBObject> get() {
		while(!available) {
			try {
				wait();
			} catch (InterruptedException e) {}
		}
		try {
			DBCollection collection = connMongo.getCollection();
			DBCursor results = collection.find(new BasicDBObject("migrated", "false"));
			System.out.println(results.count());
			return results.toArray();
		} finally {
			available = false;
			notifyAll();
		}
	}

	public synchronized void put(String message) {
		if(available) {
			try {
				wait();
			} catch (InterruptedException e) {}
		}
		try {
			BasicDBObject document = new BasicDBObject();
			JSONObject jsonObject = convertToJSON(message);

			if (checkHumidityAndTemperatureValues(jsonObject)) {
				if (checkDateTimeValue(jsonObject)) {
					document = addToDoc(document, jsonObject);
					if (document != null) {
						connMongo.getCollection().insert(document);
					}
				}
			}
		} finally {
			available = true;
			notifyAll();
		}
	}

	private BasicDBObject addToDoc(BasicDBObject document, JSONObject jsonObject) {
		Iterator<String> iterator = jsonObject.keys();
		while (iterator.hasNext()) {
			String key = iterator.next();
			if (key.equals("temperature") || key.equals("humidity") || key.equals("date") || key.equals("migrated")
					|| key.equals("time")) {
				try {
					document.append(key, jsonObject.get(key));
				} catch (JSONException e) {
					writeToLog("JSON format error");
				}
			}
		}
		return document;
	}

	private boolean checkDateTimeValue(JSONObject jsonObject) {
		String date;
		String time;
		boolean isValid = true;
		try {
			date = jsonObject.getString("date");
			time = jsonObject.getString("time");

			// check if time is valid
			if (Integer.parseInt(time.substring(0, 2)) > 24 || Integer.parseInt(time.substring(0, 2)) < 0
					|| Integer.parseInt(time.substring(3, 5)) > 60 || Integer.parseInt(time.substring(3, 5)) < 0
					|| Integer.parseInt(time.substring(6, 8)) > 60 || Integer.parseInt(time.substring(6, 8)) < 0) {
				writeToLog("Wrong time values");
				isValid = false;
			}
			// format date and time
			DateFormat formatterComplete = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date dateTimeValue = formatterComplete.parse(date + " " + time);

			// format current date and time
			String nowDateTimeString = formatterComplete.format(Calendar.getInstance().getTime());
			Date nowDateTimeValue = formatterComplete.parse(nowDateTimeString);

			// check if date is in the future
			if (dateTimeValue.after(nowDateTimeValue) || Integer.parseInt(date.substring(6)) <= DATELOW) {
				writeToLog("Date and time - invalid!");
				isValid = false;
			}
		} catch (JSONException e) {
			writeToLog("JSON format error - Date");
			isValid = false;
		} catch (ParseException e) {
			writeToLog("JSON parse error - Date");
			isValid = false;
		}
		return isValid;
	}

	private boolean checkHumidityAndTemperatureValues(JSONObject jsonObject) {
		boolean isValid = true;
		System.out.println(jsonObject);
		try {
			if (Double.parseDouble(jsonObject.getString("temperature")) < TEMPERATURELOW
					|| Double.parseDouble(jsonObject.getString("temperature")) > TEMPERATUREHIGH) {
				writeToLog("Invalid temperature value:" + jsonObject.getString("temperature"));
				isValid = false;
			}

			if (Double.parseDouble(jsonObject.getString("humidity")) < HUMIDITYLOW
					|| Double.parseDouble(jsonObject.getString("humidity")) > HUMIDITYHIGH) {
				writeToLog("Invalid humidity value");
				isValid = false;
			}
			if(jsonObject.getString("temperature").endsWith(".") || jsonObject.getString("humidity").endsWith(".")) {
				writeToLog("Temperature/Humidity ends with .");
				isValid = false;
			}
		} catch (NumberFormatException e) {
			writeToLog("Temperature/Humidity values are not numeric");
			isValid = false;
		} catch (JSONException e) {
			writeToLog("JSON format error - temperature/humidity");
			isValid = false;
		}
		return isValid;
	}

	private JSONObject convertToJSON(String message) {
		if (!message.startsWith("{", 0)) {
			message = "{" + message;
		}
		if (!message.startsWith("}", message.length() - 1)) {
			message = message + "}";
		}
		JSONObject jsonObject = null;
		try {
			jsonObject = new JSONObject(message);
			jsonObject.put("migrated", "false");
		} catch (JSONException e) {
			writeToLog("JSON parse error");
		}
		return jsonObject;
	}

	public ConnectToMongo getConnMongo() {
		return connMongo;
	}
	
	public void writeToLog(String string) {
		FileWriter writer;
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			writer = new FileWriter(new File("./errors.log"), true);
			writer.append(dateFormat.format(date) + " | " + string+"\n");
			writer.close();
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		} 
	}

}
