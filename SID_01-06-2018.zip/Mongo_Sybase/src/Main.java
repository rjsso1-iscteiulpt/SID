import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

public class Main {

	public static void main(String[] args) {
		
		ConfFileReader reader = new ConfFileReader();
		JSONObject confJson  = reader.readFromFile();

		// estabelecimento das liga��es
		ConnectToMongo connMongo = new ConnectToMongo(confJson);
		ConnectToSybase connSybase = new ConnectToSybase(confJson);

		// lidar com leituras e escritas
		ConnectionHandler connHandler = new ConnectionHandler(connMongo, connSybase);

		// chama os m�todos de leitura e escrita
		new ConnectToSensor(connHandler,confJson);
		new Thread(new SendToSybase(connHandler, connSybase, confJson)).start();;
	}

}
