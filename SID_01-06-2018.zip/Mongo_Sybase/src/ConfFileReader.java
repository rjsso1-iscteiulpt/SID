import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import org.json.JSONException;
import org.json.JSONObject;

public class ConfFileReader {
	
	private final String path = "./conn_conf_file.txt";
	
	public ConfFileReader() {
	}
	
	public JSONObject readFromFile() {
		String confStringJson = "";
		JSONObject confJson = new JSONObject();
		JSONObject backupConfJson = new JSONObject();
		try {
			backupConfJson = new JSONObject("{}");
		} catch (JSONException e1) {
			System.out.println("Backup Conf Json structure corrupted");
		}
		
		try {
			Scanner in = new Scanner(new FileReader(path));
			
			StringBuilder sb = new StringBuilder();
			while(in.hasNext()) {
			    sb.append(in.next());
			}
			in.close();
			confStringJson = sb.toString();
			confJson = new JSONObject(confStringJson);
		} catch (FileNotFoundException e) {
			System.out.println("Conf file not found");
		} catch (JSONException e) {
			System.out.println("Conf Json structure corrupted");
		}
		
		if(confJson.toString() =="{}") {
			return backupConfJson;
		}else {
			return confJson;
		}
	}
	
	

}
