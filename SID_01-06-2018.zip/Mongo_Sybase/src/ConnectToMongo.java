import com.mongodb.*;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class ConnectToMongo {
	private DBCollection collection;
	private DB db;
	private MongoClient mongoClient;
	private JSONObject confJson;

	public ConnectToMongo(JSONObject confJson) {
		this.confJson = confJson;
		try {
			mongoClient = new MongoClient(new MongoClientURI(confJson.getString("mongoClientUri")));
			this.db = mongoClient.getDB(confJson.getString("dbMongoName"));
			this.collection = db.getCollection(confJson.getString("collectionMongoName"));
			// // gets the DB name from the configuration file
			// this.db = mongoClient.getDB(confJson.getString("dbMongoName"));
			// boolean auth = db.authenticate(confJson.getString("mongoUserName"),
			// confJson.getString("mongoUserPassword").toCharArray());
			// this.collection =
			// db.getCollection(confJson.getString("collectionMongoName"));
			// BasicDBObject document = new BasicDBObject();
			// document.put("name", "mkyong");
			// collection.insert(document);
			// System.out.println(collection);

			// List<ServerAddress> seeds = new ArrayList<ServerAddress>();
			// seeds.add(new ServerAddress("localhost"));
			// List<MongoCredential> credentials = new ArrayList<MongoCredential>();
			// credentials.add(MongoCredential.createMongoCRCredential("admin",
			// "sensorMedicoes", "admin".toCharArray()));

//			  List<ServerAddress> seeds = new ArrayList<>();
//	            seeds.add( new ServerAddress("localhost", 27017));
//	            List<MongoCredential> credentials = new ArrayList<>();
//	            credentials.add(MongoCredential.createMongoCRCredential("admin", "sensorMedicoes", "admin".toCharArray()));
//	           MongoClient mongoClient = new MongoClient( seeds, credentials);

//			BasicDBObject document = new BasicDBObject();
//			document.put("name", "mkyong");
//			collection.insert(document);
//			System.out.println(collection);
		} catch (JSONException e) {
			System.out.println("Error converting to JSON");
		} catch (UnknownHostException e) {
			System.out.println("Could not find host");
		}
	}

	public DBCollection getCollection() {
		return collection;
	}

	public DB getDb() {
		return db;
	}

	public MongoClient getMongoClient() {
		return mongoClient;
	}
}
