import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class SendToSybase implements Runnable {

	private ConnectionHandler connHandler;
	private ConnectToSybase connSybase;
	private JSONObject confJson;

	public SendToSybase(ConnectionHandler connHandler, ConnectToSybase connSybase, JSONObject confJson) {
		this.connHandler = connHandler;
		this.connSybase = connSybase;
		this.confJson = confJson;
	}

	@Override
	public void run() {
		while (true) {
			try {
				// waits the export periodicity to get data from mongo
				Thread.sleep(Long.parseLong(confJson.getString("exportPeriod")));
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (JSONException e) {
				e.printStackTrace();
			}
			// calls the method "get()" that gets the data that wasn't yet migrated
			List<DBObject> dataFromMongo = connHandler.get();
			if (!dataFromMongo.isEmpty()) {
				// for each line from mongo that wasn't migrated, calls the method insert()
				for (DBObject result : dataFromMongo) {
					insert(result);
				}
			}
		}
	}

	public void insert(DBObject result) {

		try {
			Statement stmt = connSybase.getConn().createStatement();
			// handles the data from mongo:
			double temperature = Double.parseDouble(result.get("temperature").toString());
			double humidity = Double.parseDouble(result.get("humidity").toString());
			String timeString = result.get("time").toString();
			String dateString = result.get("date").toString();

			// Convert time variable from String to sql.Time
			SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
			long time = 0;
			try {
				time = formatter.parse(timeString).getTime();
			} catch (ParseException e) {
				e.printStackTrace();
			}
			java.sql.Time timeValue = new Time(time);

			// Convert date variable from String to sql.Date
			SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date date = null;
			try {
				date = format.parse(dateString);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			java.sql.Date dateValue = new java.sql.Date(date.getTime());

			// inserts values into HumidadeTemperatura table:
			stmt.executeUpdate("INSERT INTO " + confJson.getString("tableSybaseName")
					+ " (HoraMedicao, DataMedicao, ValorMedicaoTemperatura, ValorMedicaoHumidade) "
					+ "VALUES('" + timeValue + "','" + dateValue + "','" + temperature + "', '" + humidity + "')");
			changeToMigrated(result);
		} catch (SQLException e) {
			System.out.println("SQL problem: could not insert into Sybase");
		} catch (JSONException e) {
			System.out.println("Table not found");
		}
	}

	private void changeToMigrated(DBObject result) {
	        BasicDBObject query = new BasicDBObject();
	        query.append("_id",result.get("_id"));
	        BasicDBObject setData = new BasicDBObject();
	        setData.append("migrated", "true");
	        BasicDBObject update = new BasicDBObject();
	        update.append("$set", setData);
	        connHandler.getConnMongo().getCollection().update(query, update);
	}
}
