import java.awt.BorderLayout;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class ConnectionHandler {
	private static final double TEMPERATURELOW = -150;
	private static final double TEMPERATUREHIGH = 150;
	private static final double HUMIDITYLOW = 0;
	private static final double HUMIDITYHIGH = 100;
	private static final int DATELOW = 0;
	private ConnectToMongo connMongo;
	final Lock lock = new ReentrantLock();

	public ConnectionHandler(ConnectToMongo connMongo, ConnectToSybase connSybase) {
		this.connMongo = connMongo;
	}

	public synchronized List<DBObject> get() {
		lock.lock();
		try {
			DBCollection collection = connMongo.getCollection();
			DBCursor results = collection.find(new BasicDBObject("migrated", "false"));
			System.out.println(results.count());
			return results.toArray();
		} finally {
			lock.unlock();
		}
	}

	public synchronized void put(String message) {
		lock.lock();
		try {
			BasicDBObject document = new BasicDBObject();
			JSONObject jsonObject = convertToJSON(message);

			if (checkHumidityAndTemperatureValues(jsonObject)) {
				if (checkDateTimeValues(jsonObject)) {
					document = addToDoc(document, jsonObject);
					if (document != null) {
						System.out.println(jsonObject);
						System.out.println(document);
						connMongo.getCollection().insert(document);
					}
				}
			}
		} finally {
			lock.unlock();
		}
	}

	private BasicDBObject addToDoc(BasicDBObject document, JSONObject jsonObject) {
		Iterator<String> iterator = jsonObject.keys();
		while (iterator.hasNext()) {
			String key = iterator.next();
			if (!key.equals("temperature") && !key.equals("humidity") && !key.equals("date") && !key.equals("migrated")
					&& !key.equals("time")) {
				displayErrorMessages("Wrong structure");
			}
			try {
				document.append(key, jsonObject.get(key));
			} catch (JSONException e) {
				displayErrorMessages("JSON format error");
			}
		}
		return document;

	}

	private boolean checkDateTimeValues(JSONObject jsonObject) {
		String date;
		boolean isValid = true;
		try {
			date = jsonObject.getString("date");
			System.out.println(date);
			DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date dateValue = formatter.parse(date);
			String nowString = formatter.format(Calendar.getInstance().getTime());
			Date nowValue = formatter.parse(nowString);

			if (dateValue.after(nowValue)) {
				displayErrorMessages("Date is invalid!");
				isValid = false;
			}

		} catch (JSONException e) {
			displayErrorMessages("JSON format error - Date");
			isValid = false;
		} catch (ParseException e) {
			displayErrorMessages("JSON parse error - Date");
			isValid = false;
		}
		return isValid;
	}


	private boolean checkHumidityAndTemperatureValues(JSONObject jsonObject) {
		boolean isValid = true;
		System.out.println(jsonObject);
		try {
			if (Double.parseDouble(jsonObject.getString("temperature")) < TEMPERATURELOW
					|| Double.parseDouble(jsonObject.getString("temperature")) > TEMPERATUREHIGH) {
				displayErrorMessages("Invalid temperature value:" + jsonObject.getString("temperature"));
				isValid = false;
			}

			if (Double.parseDouble(jsonObject.getString("humidity")) < HUMIDITYLOW
					|| Double.parseDouble(jsonObject.getString("humidity")) > HUMIDITYHIGH) {
				displayErrorMessages("Invalid humidity value");
				isValid = false;
			}
		} catch (NumberFormatException e) {
			displayErrorMessages("Temperature/Humidity values are not numeric");
		} catch (JSONException e) {
			displayErrorMessages("JSON format error - temperature/humidity");
		}
		return isValid;
	}

	private JSONObject convertToJSON(String message) {
		if (!message.startsWith("{", 0)) {
			message = "{" + message;
		}
		if (!message.startsWith("}", message.length() - 1)) {
			message = message + "}";
		}
		JSONObject jsonObject = null;
		try {
			jsonObject = new JSONObject(message);
			jsonObject.put("migrated", "false");
		} catch (JSONException e) {
			displayErrorMessages("JSON parse error");
		}
		return jsonObject;
	}

	public void displayErrorMessages(String message) {
		JFrame frame = new JFrame("Error");
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(new JLabel(message), BorderLayout.CENTER);
		frame.add(panel);
		frame.setSize(200, 100);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

	public ConnectToMongo getConnMongo() {
		return connMongo;
	}

}
