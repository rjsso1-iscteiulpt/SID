import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class ConnectionHandler {
	private ConnectToMongo connMongo;
	final Lock lock = new ReentrantLock();

	public ConnectionHandler(ConnectToMongo connMongo, ConnectToSybase connSybase) {
		this.connMongo = connMongo;
	}

	public synchronized List<DBObject> get() {
		lock.lock();
		try {
			DBCollection collection = connMongo.getCollection();
			BasicDBObject migratedQuery = new BasicDBObject();
			migratedQuery.put("migrated", new BasicDBObject("$eq", "false"));
			DBCursor results = collection.find(new BasicDBObject("migrated", "false"));
			
//			System.out.println(cursor);
//			while (cursor.hasNext()) {
//				System.out.println(cursor.next());
//			}
			return results.toArray();
		} finally {
			lock.unlock();
		}	
	}

	public synchronized void put(String value) {
		BasicDBObject document = new BasicDBObject();
		String[] tokens = value.split("time");
		JFrame frame = new JFrame();
		
		tokens[0]+= "migrated:false,";
		
		String newValue = tokens[0] +"time" + tokens[1];
		newValue.trim();
		newValue= newValue.substring(1, newValue.length()-1); //corta as chavetas
		
		String[] tokens2 = newValue.split(",");
		
		String[][] valueMatrix = new String[tokens2.length][2];
		JSONObject json = new JSONObject();
		
		for(int i=0; i<tokens2.length;i++) {
			String[] tokens3 = tokens2[i].split(":");
			for(int j=0; j<2; j++) {					
				valueMatrix[i][j] = tokens3[j]; 
			}
			try {
				json.put(valueMatrix[i][0], valueMatrix[i][1]);
			} catch (JSONException e) {
				JOptionPane pane = new JOptionPane("JSON error");
				frame.add(pane);
				frame.setVisible(true);
			}
		}
		
		@SuppressWarnings("unchecked")
		Iterator<String> iterator = json.keys();
	
		/*
		 * a parte de verificar a expressão discute-se melhor depois
		 */
		JOptionPane pane = new JOptionPane();
		frame.add(pane);
		try {
			
			if(Double.parseDouble(json.getString("temperature"))< -10 || Double.parseDouble(json.getString("temperature")) > 50 ) {
				pane.setMessage("Invalid temperature value");
				return;
			}
			if(Double.parseDouble(json.getString("humidity"))< 0 || Double.parseDouble(json.getString("humidity")) > 100 ) {
				pane.setMessage("Invalid humidity value");
				return;
			}
			
			String string = json.getString("date")+" "+json.getString("time");
			DateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); //não sei qual é o formato certo
			Date date = format.parse(string);
			String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			Date now = format.parse(timeStamp);

			if(date.after(now)) {
				pane.setMessage("Invalid date/time value");
				return;
			}
			
				
			while(iterator.hasNext()) {
				String key = iterator.next();
				key.trim();
				if(!key.equals("temperature") &&!key.equals("humidity")&&!key.equals("date")&&!key.equals("migrated")&&!key.equals("time")) {
					pane.setMessage("Wrong structure");			
					frame.setVisible(true);
					return;
				}	
				document.append(key, json.get(key));
			}
		} catch (NumberFormatException | JSONException e ) {
			pane.setMessage("JSON error");
			frame.setVisible(true);
		}catch(ParseException e) {
			pane.setMessage("Date error");
			frame.setVisible(true);
		}
		
		connMongo.getCollection().insert(document);
	}

}
